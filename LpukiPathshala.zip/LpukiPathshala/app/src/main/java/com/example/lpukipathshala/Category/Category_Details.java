package com.example.lpukipathshala.Category;

public class Category_Details {
    private String cname;

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public Category_Details(String cname) {
        this.cname = cname;
    }

}
